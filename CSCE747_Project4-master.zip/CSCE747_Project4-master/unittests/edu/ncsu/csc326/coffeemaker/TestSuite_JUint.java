package edu.ncsu.csc326.coffeemaker;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
   CoffeeMakerTest.class,
   InventoryTest.class,
   RecipeBook_Test.class,
   RecipeTest.class,
})
public class TestSuite_JUint
{
	
}
